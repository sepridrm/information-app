@extends('adminlte::errors')

@section('main-content')
    <div class="error-page">
        <h2> 404</h2>
    </div>
@endsection
